# API key privacy

Codex must not read, print, or expose API key values. Do not inspect the contents of secret-bearing configuration or credential files, including this repo's `config.yml` and `.local-setup/config*.yml` backups.

The project launcher and its normal runtime may read credentials internally for user-authorized setup checks and benchmark runs. Do not display API keys in logs, chat, or tool output.
