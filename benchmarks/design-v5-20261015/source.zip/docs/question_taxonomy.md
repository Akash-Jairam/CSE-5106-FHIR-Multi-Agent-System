# Question taxonomy and initial support contract

This plan studies factual questions about one patient's recorded care. “Support” means that a question has an explicit, testable interpretation over available FHIR records; it does not mean answering arbitrary clinical questions. The first implementation should cover Patient, Encounter, and quantitative Observation queries after their mappings are checked against the raw dataset. Diagnosis, prognosis, treatment recommendations, external literature, notes, images, cohort queries, and conversational follow-ups are outside the initial task.

## What the released questions actually contain

The audited file is `final_dataset/questions_answers_sql_fhir.csv`, SHA-256 `e2045692fef7f5f4f77496935160f5fc727e162d213e94feed61401948e512a0`. It contains **2,931 unique questions, 94 patients, and 76 canonical templates**. The companion SQL CSV contains 3,105 questions; the FHIR mapping CSV contains 43,403 mapping rows for 2,931 questions. Mapping rows are not additional questions.

The following mutually exclusive classification uses the canonical template's requested operation. These are descriptive counts of the whole release, not validated support counts. “Empty/null” counts exact `[]` and `[[None]]` labels; it excludes false and zero.

| Primary operation | Templates | Questions | Empty/null |
|---|---:|---:|---:|
| Timestamp selection: when an event occurred | 17 | 646 | 130 |
| Ordered value selection: first/last value or category | 12 | 624 | 96 |
| Existence: whether a recorded event occurred | 16 | 543 | 0 |
| Scalar aggregation: minimum, maximum, mean, total | 5 | 328 | 89 |
| Count: visits, events, or distinct entities | 7 | 196 | 0 |
| Elapsed duration relative to current encounter | 5 | 139 | 139 |
| Difference between two selected measurements | 3 | 137 | 34 |
| Comparison between two selected measurements | 2 | 106 | 23 |
| Duration of a completed stay | 2 | 77 | 0 |
| Aggregation grouped by day/month/year | 4 | 77 | 21 |
| Attribute lookup | 2 | 51 | 0 |
| List of event times | 1 | 7 | 1 |
| **Total** | **76** | **2,931** | **533** |

The proposal's three families remain useful presentation categories, but they hide important distinctions. For reporting, map lookup/count to attribute lookup, existence, count, and event listing (797 questions); temporal selection to timestamp and ordered value selection (1,270); numerical reasoning to the remaining operations (864). This crosswalk is exhaustive; the MVP implements only selected operations within these families. Report the finer operation tags alongside broad-family results.

Source-table coverage also matters: prescriptions 602, laboratory events 570, chart observations 555, microbiology 334, admissions 317, output events 166, procedures 133, ICU stays 121, transfers 54, patients 44, and diagnoses 35. An operation demonstrated on vital signs is not automatically supported on medication doses or microbiology results. These source tables do not each correspond to one FHIR resource type.

## Initial support contract

The proposed MVP contains the following capabilities, conditional on raw-record semantic checks:

| Capability | Proposed accepted interpretation | Conditions to establish before evaluation |
|---|---|---|
| Patient attribute lookup | A recorded, explicitly mapped attribute, initially sex/gender as represented in this dataset | Preserve the source field's meaning and distinguish missing from an inferred value |
| Encounter lookup/count | Hospital admission or ICU-stay information, including distinct visit counts | Identify hospital/ICU Encounter profiles and parent-child links; avoid counting every nested Encounter as an admission |
| Observation existence/lookup | A named vital sign or laboratory measurement, optionally in a defined window | Resolve the concept to validated codes/labels, retain value and unit, establish patient and encounter scope |
| Observation count | Number of distinct matching recorded measurements/tests in the specified scope | Validate the event-identity and deduplication rule; do not count components or duplicate records as independent tests |
| First/last selection | Earliest/latest qualifying event, returned as a time or measurement | Use the measurement/event timestamp; specify ties and date precision |
| Threshold selection | Existence or first/last measurement strictly above/below a stated threshold | Honor strict inequalities and compatible units; do not infer clinical abnormality |
| Scalar numerical aggregation | Minimum, maximum, or mean of matching measurements | Define contributors, missing-value handling, units, and inclusion boundaries |

Absolute dates, complete calendar windows, and relative windows with an explicit reference time are candidates. First/last completed hospital or ICU encounters require explicit encounter-selection rules. The benchmark's “last hospital encounter” example selects a discharged encounter; simply choosing the latest Encounter would change the task. Do not use the wall clock for deidentified dates.

Initially defer two-point changes/comparisons, completed-stay duration, elapsed-since queries, grouped time series, and arbitrary event lists. Defer medication, procedure, diagnosis, microbiology, output, and transfer-specific questions until their mappings and operations have separate acceptance checks. These are scope choices, not claims that the operations are impossible. Medication dose totals particularly require a definition of what is summed and how dose units are handled.

The audit's `candidate_support_status` is a deliberately conservative planning heuristic. It identifies rows in candidate domains and operations, with current-encounter questions deferred. It is not a semantic support detector: code mappings, encounter links, units, temporal precision, ties, and missing-data behavior must be adjudicated first. For example, its seven marital-status candidates remain deferred until a dataset-specific field mapping is confirmed; initial attribute lookup covers only the validated sex/gender field. Freeze the final eligibility manifest only after those checks; do not advertise its preliminary row count as supported coverage or silently drop difficult cases after seeing model results.

## Three concrete development cases

Reserve every question for the proposal's three example patients for development, as the proposal promises. These cases illustrate different contracts:

| Question ID | Released question | Reference answer |
|---|---|---|
| `0565efc9f6e08966694b0d93` | How many times did patient 10001217 go to the hospital? | `2` |
| `672d81cda5b780896726e4f2` | When was patient 10015860's respiratory rate less than 21.0 for the first time since 06/06/2186? | `2186-09-15 18:00:00` |
| `0c93a24758fe815a4f4bf747` | What was the maximum value of pt on patient 10004235 in their last hospital encounter? | `12.3` |

The admission question counts distinct hospital admissions. The respiratory question uses reference time `2186-12-31 23:59:00`, a strict `<21` predicate, and measurement time rather than issuance time. The PT question resolves the last completed hospital encounter and compares its eligible PT results. The final answer should carry the units established from FHIR even when the benchmark's scalar label omits them. These are development fixtures, not evaluation results.

## Tag questions on several independent axes

A single label such as “temporal” is insufficient to explain failure. Store the following offline tags in the question manifest; the runtime parser must infer its interpretation from the permitted question input.

| Axis | Example values |
|---|---|
| Primary operation | The twelve mutually exclusive classes above |
| Data domain | Patient attribute; hospital/ICU encounter; vital; laboratory; deferred domain |
| Scope | Entire patient record; selected hospital/ICU encounter; one or two measurement windows |
| Time window | Absolute day/month/year; since-date; reference-relative interval; encounter-relative |
| Selector | None; first; last; second; second-to-last; extremum with temporal tie-break |
| Predicate | Concept/code match; strict numeric threshold; route/specimen/category; conjunction/disjunction |
| Output type | Boolean; integer count; quantity and unit; timestamp; category; set; ordered series |
| Evidence requirement | Selected record; contributing set; encounter dependency; complete negative search |
| Answerability | Answer found; complete no-match; missing required field; incomplete retrieval; unsupported |

Scope tags are intentionally nonexclusive. The audit identifies 879 questions with absolute-calendar windows and 651 with reference-time-relative calendar windows; a question may have two scopes. Local first/last ordering can appear without a global date window. Preserve all selected records for ties when the requested output is a set; do not force a multi-value reference into a scalar.

## Empty answers and release anomalies

There are 387 `[]` labels and 146 `[[None]]` labels: **533/2,931, or 18.18%**, overall. Treat their scoring semantics separately from the system's evidence status. A count of zero and Boolean false are valid answers when a complete search establishes them. A null numeric aggregate is not zero. An empty event selection means no matching recorded event only when the relevant scope was searched completely. A truncated tool result, failed request, or unsupported mapping means unknown/incomplete evidence, not a negative answer.

All **139 elapsed-duration questions have `[]` labels**, span five templates, and concern only four patients. Example `06ba722e2ac0589ffacd1249` asks how many hours have elapsed since patient 10039831's last creatinine test on the current hospital visit. Across all operations, the audit tags 191 current-encounter questions, 179 with empty/null labels. This concentration requires source-semantic investigation; it does not establish why the labels are empty. Exclude this family from claims about demonstrated duration reasoning until adjudicated.

The `true_answer` field is not reliable JSON or Python literal syntax: **103 strings fail `ast.literal_eval`, and all 103 contain embedded newlines**, consistent with NumPy-style multirow representations. Implement an explicit offline normalizer and audit its failures; never use unrestricted `eval`, silently discard failed rows, or compare the raw serialization as if it were a typed answer. Also, **701 questions have no annotated FHIR IDs**, a different population from empty answers. Annotation overlap cannot establish complete evidence, particularly for negative results.

## Splits, leakage, and acceptance

Released train/valid/test contain 2,098/424/409 questions and 94/91/90 patients. Every validation and test patient appears in training; validation and test share 87 patients. Use patient-disjoint development and evaluation manifests. Preserve original split and template membership as offline metadata: 31 templates are absent from released training, with 17 novel validation templates (112 questions) and 14 novel test templates (98 questions). Patient generalization and unseen-template generalization are different claims.

Runtime agents receive only the question, patient FHIR ID, explicit assumptions, and allowed records/tools. Keep `true_answer`, `true_fhir_ids`, SQL, `proc_query`, template, `val_dict`, and offline classification/support tags out of prompts and tools. In particular, `val_dict` contains resolved operators and time scopes and would turn interpretation into metadata lookup. Gold-dependent packet perturbations belong exclusively to the offline harness.

Before accepting a capability, verify representative nonempty and empty cases against raw FHIR, demonstrate the expected field/time/unit semantics, retain complete contributors or a coverage record, and define the typed scorer. Freeze these rules on development patients. Stratify the later evaluation by operation and domain, retain empty cases, and report excluded/unsupported strata explicitly. A capability earns support through semantic validation and reproducible runs, not template matching alone.

## Reproduce the audit

From the repository root:

```sh
python3 docs/audit/audit_questions.py final_dataset/questions_answers_sql_fhir.csv --output-dir docs/audit
```

The script uses only Python's standard library. `question_audit.json` records hashes and counts; `question_templates.csv` supplies per-template counts and actual examples; `question_classifications.csv` supplies row-level offline tags. They are analysis artifacts, not an application implementation or final experiment split.
