# Repository audit for implementation planning

This is a **static, plan-only audit**, performed on 2026-10-07. It identifies work required before the first defensible multi-agent run; it does not establish that the supplied agents, credentials, FHIR service, or model endpoints work.

## Provenance and evidence limits

- Inspected repository HEAD: `d3d1364348cd7f84c51e3dede76d4646a866d1a8`.
- Dataset: [`final_dataset/questions_answers_sql_fhir.csv`](../final_dataset/questions_answers_sql_fhir.csv).
- Dataset SHA-256: `e2045692fef7f5f4f77496935160f5fc727e162d213e94feed61401948e512a0`.
- Evidence: Python/source inspection and read-only CSV analysis. No agent execution, paid API calls, credential inspection, raw-data download, dependency installation, or service connectivity checks were performed.
- No raw NDJSON, SQLite database, automated test suite, or container configuration was found in the supplied repository. `questions_answers_fhir.csv` contains resource-ID mapping metadata, not patient resource bodies.

Line links below refer to this audited source revision. Existing untracked `docs/` work belongs to the planning effort; application code was not changed.

## Reusable foundation

The five supplied strategies provide useful baselines. However, “multi-turn” currently means one ReAct agent repeatedly calling tools, not multiple agents with distinct responsibilities: see the [resource-agent loop](../agent/multi_turn_resource_agent.py#L86). A new retrieval–analysis–verification system must therefore be implemented and evaluated as an additional architecture.

Reuse the [tool registry](../tools/registry.py#L4), [FHIR pagination client](../fhir_client.py#L53), and [agent factory](../utils/core_utils.py#L272). The [base class](../agent/base_agent.py#L20) offers configuration and aggregate usage bookkeeping, while the existing output fields permit compatibility with upstream evaluation. The planned `mas/` package, LangGraph controller, and shared ResourceStore should adapt these interfaces after the corrections below. Give each role an explicit input/output contract; keep control flow and budgets in the controller.

The current [agent-input constructor](../utils/core_utils.py#L255) is a useful boundary: it sends question, patient FHIR ID, and supplied assumptions. Preserve that boundary. Gold SQL, answers, template labels, value dictionaries, and reference resource IDs belong only in data preparation and evaluation.

## Data scope and known exposure

The checked-in final dataset contains **2,931 questions, 76 templates, and 94 patients**: 2,098 train, 424 validation, and 409 test. Gold resource combinations are Observation 1,146; empty annotation 701; Medication plus MedicationRequest 498; Encounter 392; Procedure 108; Patient 44; Condition 35; and Location 7. These are gold-annotation categories, not a complete inventory of resources needed to solve each question.

There are **533 empty-answer rows** under the explicit `[]` / `[[None]]` convention: 387 and 146 respectively. Separately, **701 rows have empty gold resource annotations**: 387 `[]`, 144 `[[None]]`, and 170 `[[0]]`. A valid zero or false answer must not be relabeled as missing information. Empty annotations also cannot prove that a retrieval error occurred.

Three existing few-shot examples exactly match dataset questions, including two original test rows. Their prompts reveal answer-bearing patient facts. Reserve all three patients for development in any new patient-disjoint split, and disclose these exclusions in benchmark-compatible reporting.

| Original split / question ID | Exposed patient | Patient FHIR ID |
|---|---|---|
| train / `26ca7defafe27bfa854cf965` | `10009628` | `51d2190c-cc46-56c5-b2ea-363895cbea75` |
| test / `7b11c8a07c7b85627d2a9c47` | `10018423` | `bbad4581-d089-54a7-b7a0-8d986c5fb5ec` |
| test / `833f3dcc0c1a68ee5c293d02` | `10022041` | `52462b6a-9b39-5460-9ee6-1a2d7a20394e` |

See the [ICU example](../agent/multi_turn_resource_agent.py#L42), [procedure example](../agent/multi_turn_resource_agent.py#L53), and [diagnosis example](../agent/multi_turn_resource_agent.py#L65). Replace examples with development-only or synthetic examples; replacing prompts does not erase prior exposure during development. The runner currently [drops split/template metadata](../utils/core_utils.py#L245) and selects no split, so explicit selection is required.

Supplied assumptions are [derived from SQL and template metadata](../utils/fhir_utils.py#L360), including anchor time, terminology, table hints, and dose-column guidance. Keep them consistent across architectures and describe the task as “NL question plus supplied benchmark context.” This is not an evaluation of wholly unassisted clinical language understanding.

## Priority 0: correctness and execution boundaries

Resolve these before any meaningful pilot; add focused fixture tests for their failure cases.

| Finding | Evidence and required correction |
|---|---|
| Incorrect resource-ID search | [Resource tool](../tools/resource_tools.py#L17) uses `?id=`. Use `_id`, as the [existing client](../fhir_client.py#L79) does, or a resource read. `_id` is the [FHIR R4 search parameter](https://hl7.org/fhir/R4/search.html#id). |
| Type-blind patient search | [Patient tool](../tools/resource_tools.py#L36) applies `?patient=` to every type. Read Patient by its ID; follow references for Medication and Location; validate other supported search parameters. |
| Incomplete REST retrieval | [REST tool](../tools/request_tools.py#L12) reads only one response page. Reuse pagination and record completeness before count, extrema, or absence claims. |
| Lost accumulated evidence | [Resource agent](../agent/multi_turn_resource_agent.py#L128) and [code agent](../agent/multi_turn_code_resource_agent.py#L219) overwrite previous same-type results. ResourceStore must union by `(resourceType,id)` while preserving individual retrieval events. |
| Unrestricted generated code | [Executor](../tools/python_executor.py#L27) accepts a timeout but executes host-process `exec` without enforcing it. Use deterministic typed analysis operations initially; isolate generated code with real limits if later enabled. |
| Broken error/result contract | The [code agent](../agent/multi_turn_code_resource_agent.py#L218) indexes a resource-type key even when a tool returns an error. Introduce structured success/error results. The [executor](../tools/python_executor.py#L52) requires `answer`, while [examples](../agent/multi_turn_code_resource_agent.py#L69) only print; reconcile this contract. |

The HTTP client also has [no explicit request timeout or page budget](../fhir_client.py#L60). Enforce both; an interrupted fetch must be recorded as incomplete rather than an empty clinical result.

## Priority 1: experiment integrity and measurement

Fix runner startup and resume behavior: [omitted output](../run_agent.py#L124) calls `splitext(None)`; a [bare output filename](../run_agent.py#L147) attempts to create an empty directory path; [completed runs](../run_agent.py#L189) can construct a zero-process pool. Replace [boolean string parsing](../run_agent.py#L48), fail on unsuccessful [configuration validation](../run_agent.py#L80), and verify run identity before resuming. Include dataset hash, selected question IDs, code revision, prompts, role models, and budgets in that identity.

The LLM wrapper's [`max_tokens`](../utils/core_utils.py#L345) checks estimated input length but does not set a completion limit. Enforce per-call output limits and shared per-question call, token, time, and cost budgets. Log each retry: [whole-agent retries](../utils/core_utils.py#L292) and [LLM retries](../utils/core_utils.py#L354) otherwise obscure spending and failures. Avoid [per-call cost rounding](../agent/base_agent.py#L51).

Preserve full structured events independently of display traces: current processing [truncates resource lists](../utils/core_utils.py#L198) and [discards usage/trace on errors](../utils/core_utils.py#L217). Log role decisions, tool arguments/results, evidence IDs, completeness, verifier verdicts, repairs, latency, usage, and termination status. Store bounded decision summaries, not a requirement for private chain-of-thought.

The [cache](../tools/cache.py#L10) never expires, lacks dataset/store identity in its [key](../tools/cache.py#L22), and [caches errors](../tools/cache.py#L130). Scope it to an immutable dataset/backend fingerprint, exclude errors, use atomic writes, and distinguish cache hits from network activity when reporting latency.

## Priority 1: evaluation corrections

Preserve upstream metrics as separately labeled compatibility results. Add corrected metrics rather than silently changing their meaning:

- Existing [recall](../utils/metrics_utils.py#L5) defaults to all required IDs recovered; also report fractional set recall.
- Existing [resource filtering](../evaluation_metrics.py#L350) removes predictions from nongold types before precision. Report all-type fetched-resource precision and cited-evidence precision separately; necessary context resources may be absent from gold annotations.
- [NaN conventions](../utils/metrics_utils.py#L27) alter metric denominators. State empty-set handling and report denominator counts.
- [Reference rewriting](../evaluation_metrics.py#L478) converts every empty gold annotation to “no answer.” Preserve valid zero/false and distinguish missing values.
- The judge accepts [missing timestamp precision](../evaluation_metrics.py#L260) and [incorrect totals containing a correct component](../evaluation_metrics.py#L268); its [retry loop](../evaluation_metrics.py#L291) is unbounded. Prefer typed deterministic scoring, bounded judging for unresolved text, and a stratified manual audit. Keep runtime failures in the headline denominator.

## Planned backend setup, not verified setup

**GCP** is the upstream path: import the public MIMIC FHIR demo, configure ADC, then verify known IDs and resource counts. The [client](../fhir_client.py#L14) is currently coupled to GCP authentication and URL construction. No working store was established by this audit.

**Local replay** requires acquiring complete NDJSON and building indexed patient/type/reference access behind the same tool interface. It supports deterministic resource-tool experiments but must not be described as a full FHIR REST server. A local FHIR server is a separate option if arbitrary REST search becomes essential. Synthetic fixtures prove orchestration behavior only, not benchmark accuracy.

The [setup script](../scripts/setup_data.sh#L9) downloads SQL demo 2.2, while the [README](../README.md#L45) specifies FHIR demo 2.1.0. Record both versions and verify identifier coverage before using either backend. The next milestone is a tested, bounded retrieval–analysis–verification run on a frozen development subset, with complete records suitable for the later report.
