#!/usr/bin/env python3
"""Offline descriptive audit; NEVER pass template/SQL/labels to runtime agents.

Uses Python stdlib only. Primary operation is classified from canonical template
text for dataset analysis, not a deployable question parser. Candidate MVP status
is a conservative planning heuristic, not a claim of validated FHIR support.
No executable code or SQL from input is evaluated; ast.literal_eval only parses
literal metadata for the offline audit.
"""
import argparse
import ast
import collections
import csv
import hashlib
import itertools
import json
from pathlib import Path

EMPTY_ENCODINGS = {'[]', '[[None]]'}
CORE_DOMAINS = {'patients', 'admissions', 'icustays', 'chartevents', 'labevents'}
CORE_OPERATIONS = {'attribute_lookup', 'ordered_value_selection', 'timestamp_selection',
                   'existence', 'count', 'scalar_aggregation'}

def primary_operation(template):
    if template.startswith('Has_verb'): return 'existence'
    if template.startswith('Count'): return 'count'
    if template.startswith('When'): return 'timestamp_selection'
    if 'length of' in template: return 'completed_stay_duration'
    if template.startswith('How many'): return 'elapsed_duration'
    if template.startswith('What is the change'): return 'difference'
    if template.startswith('Is '): return 'pairwise_comparison'
    if template.startswith('List the [unit_average]'): return 'grouped_aggregation'
    if template.startswith('List the hospital'): return 'event_listing'
    if 'total ' in template or '[agg_function]' in template: return 'scalar_aggregation'
    if '[time_filter_exact1]' in template: return 'ordered_value_selection'
    if template in {'What is the gender of patient {patient_id}?',
                    'What is_verb the marital status of patient {patient_id} [time_filter_global1]?'}:
        return 'attribute_lookup'
    raise ValueError('Unclassified template: ' + template)

def scope_axes(row, metadata):
    types = {v['type'] for v in metadata['time_placeholder'].values()}
    axes = set()
    if any(t.startswith('abs-') for t in types): axes.add('absolute_calendar_window')
    if any(t.startswith(('rel-day-', 'rel-month-', 'rel-year-', 'mix-')) for t in types):
        axes.add('reference_time_relative_calendar_window')
    if any(t.startswith('rel-hosp-') for t in types): axes.add('hospital_encounter_relative')
    if any(t.startswith('rel-icu-') for t in types): axes.add('icu_encounter_relative')
    if 'current hospital visit' in row['template'] or 'hospital currently' in row['template']:
        axes.add('hospital_encounter_relative')
    if 'ICU currently' in row['template']: axes.add('icu_encounter_relative')
    if 'rel-hosp-cur' in types or 'rel-icu-cur' in types or primary_operation(row['template']) == 'elapsed_duration':
        axes.add('current_encounter')
    if not axes: axes.add('no_explicit_global_window')
    return axes

def candidate_status(row, metadata):
    op = primary_operation(row['template'])
    # Current encounter semantics are unresolved and elapsed-duration labels are
    # uniformly empty in this release. Keep these in the audit, not in pilot scope.
    if 'current_encounter' in scope_axes(row, metadata):
        return 'defer_current_encounter_semantics'
    if row['main_table_name'] not in CORE_DOMAINS:
        return 'defer_additional_resource_mapping'
    if op not in CORE_OPERATIONS:
        return 'defer_additional_operation'
    return 'core_candidate_pending_raw_fhir_validation'

def summarize(rows):
    return {'questions': len(rows),
            'patients': len({r['patient_fhir_id'] for r in rows}),
            'templates': len({r['template'] for r in rows}),
            'empty_list_labels': sum(r['true_answer'] == '[]' for r in rows),
            'null_scalar_labels': sum(r['true_answer'] == '[[None]]' for r in rows),
            'empty_or_null_labels': sum(r['true_answer'] in EMPTY_ENCODINGS for r in rows)}

def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('csv_path', type=Path)
    ap.add_argument('--output-dir', type=Path, required=True)
    args = ap.parse_args()
    with args.csv_path.open(newline='', encoding='utf-8') as fh:
        rows = list(csv.DictReader(fh))
    out = args.output_dir
    out.mkdir(parents=True, exist_ok=True)
    metadata = {r['question_id']: ast.literal_eval(r['val_dict']) for r in rows}
    by_operation = collections.defaultdict(list)
    by_template = collections.defaultdict(list)
    by_candidate = collections.defaultdict(list)
    time_occurrences = collections.Counter()
    time_question_counts = collections.Counter()
    scope_counts = collections.Counter()
    comparator_counts = collections.Counter()
    resource_question_counts = collections.Counter()
    literal_errors = []
    empty_annotations = []
    multirow_newline = []
    for r in rows:
        qid = r['question_id']
        meta = metadata[qid]
        by_operation[primary_operation(r['template'])].append(r)
        by_template[r['template']].append(r)
        by_candidate[candidate_status(r, meta)].append(r)
        types = [v['type'] for v in meta['time_placeholder'].values()]
        time_occurrences.update(types)
        time_question_counts.update(set(types))
        scope_counts.update(scope_axes(r, meta))
        comparator_counts.update({v['type'] for v in meta['op_placeholder'].values()})
        ids = ast.literal_eval(r['true_fhir_ids'])
        resource_question_counts.update(k for k,v in ids.items() if v)
        if not any(ids.values()): empty_annotations.append(qid)
        try:
            ast.literal_eval(r['true_answer'])
        except (ValueError, SyntaxError):
            literal_errors.append(qid)
            if '\n' in r['true_answer']: multirow_newline.append(qid)
    split_names = sorted({r['split'] for r in rows})
    split_rows = {s: [r for r in rows if r['split']==s] for s in split_names}
    split_patients = {s: {r['patient_fhir_id'] for r in rr} for s,rr in split_rows.items()}
    split_templates = {s: {r['template'] for r in rr} for s,rr in split_rows.items()}
    stats = {
        'source_file': str(args.csv_path),
        'source_sha256': hashlib.sha256(args.csv_path.read_bytes()).hexdigest(),
        'definitions': {
            'empty_or_null_labels': 'Exact raw true_answer strings [] or [[None]]; excludes false/zero values.',
            'primary_operation': 'Mutually exclusive canonical-template heuristic; see script for rule order.',
            'scope_axes': 'Nonexclusive question-level flags; no_explicit_global_window does not mean no local ordering.',
            'support_candidate': 'Core domains patients/admissions/icustays/chartevents/labevents, basic lookup/selection/existence/count/scalar aggregate; defer current-encounter semantics and other domains/operations. Raw FHIR semantics NOT validated.',
            'metadata_access': 'This is an offline audit. SQL/template/val_dict/labels/resource annotations must not enter the runtime agent input.'},
        'overall': summarize(rows),
        'unique_question_ids': len({r['question_id'] for r in rows}),
        'released_splits': {s: summarize(rr) for s,rr in split_rows.items()},
        'patient_split_overlap': {a+'__'+b:len(split_patients[a]&split_patients[b]) for a,b in itertools.combinations(split_names,2)},
        'patients_in_all_splits': len(set.intersection(*split_patients.values())),
        'templates_absent_from_released_train': len(set.union(*split_templates.values()) - split_templates['train']),
        'unseen_template_vs_released_train': {s:{
            'templates':len(ts-split_templates['train']),
            'questions':sum(r['template'] not in split_templates['train'] for r in split_rows[s])}
            for s,ts in split_templates.items() if s!='train'},
        'source_tables': dict(sorted(collections.Counter(r['main_table_name'] for r in rows).items())),
        'primary_operations': {op:summarize(rr) for op,rr in sorted(by_operation.items())},
        'candidate_support_status': {c:summarize(rr) for c,rr in sorted(by_candidate.items())},
        'scope_axes_question_counts': dict(sorted(scope_counts.items())),
        'time_placeholder_type_occurrences': dict(sorted(time_occurrences.items())),
        'time_placeholder_type_question_counts': dict(sorted(time_question_counts.items())),
        'operator_type_question_counts': dict(sorted(comparator_counts.items())),
        'annotated_fhir_resource_type_question_counts': dict(sorted(resource_question_counts.items())),
        'empty_annotation_questions': len(empty_annotations),
        'answer_serialization_audit': {
            'literal_eval_failure_count': len(literal_errors),
            'literal_eval_failure_question_ids': literal_errors,
            'failures_with_embedded_newline_count': len(multirow_newline),
            'warning': 'true_answer uses NumPy-like string representations, not guaranteed JSON or Python literals; do not silently discard parse failures or eval arbitrary content.'},
    }
    # Companion CSVs have different grains; the mapping CSV is not question count.
    companions = {}
    for name in ('questions_answers_sql.csv', 'questions_answers_fhir.csv'):
        p = args.csv_path.with_name(name)
        if not p.exists(): continue
        with p.open(newline='', encoding='utf-8') as fh: rr=list(csv.DictReader(fh))
        companions[name] = {'rows':len(rr), 'unique_question_ids':len({r['question_id'] for r in rr}),
                             'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
        if rr and 'patient_fhir_id' in rr[0]:
            companions[name]['unique_nonempty_patient_fhir_ids'] = len({r['patient_fhir_id'] for r in rr if r['patient_fhir_id']})
    stats['companion_csvs'] = companions
    (out/'question_audit.json').write_text(json.dumps(stats, indent=2, sort_keys=True)+'\n')
    template_fields = ['template_id','primary_operation','source_tables','candidate_support_status','questions','patients','empty_list_labels','null_scalar_labels','empty_or_null_labels','train','valid','test','example_question_id','example_question','example_true_answer','template']
    with (out/'question_templates.csv').open('w', newline='', encoding='utf-8') as fh:
        w=csv.DictWriter(fh, fieldnames=template_fields);w.writeheader()
        for t,rr in sorted(by_template.items()):
            summary=summarize(rr);summary.pop('templates')
            example=next((r for r in rr if r['true_answer'] not in EMPTY_ENCODINGS),rr[0])
            w.writerow({'template_id':hashlib.sha256(t.encode()).hexdigest()[:12],
                'primary_operation':primary_operation(t),
                'source_tables':'|'.join(sorted({r['main_table_name'] for r in rr})),
                'candidate_support_status':'|'.join(sorted({candidate_status(r,metadata[r['question_id']]) for r in rr})),
                **summary, **{s:sum(r['split']==s for r in rr) for s in split_names},
                'example_question_id':example['question_id'], 'example_question':example['question'],
                'example_true_answer':example['true_answer'],'template':t})
    row_fields = ['question_id','released_split','patient_fhir_id','primary_operation','candidate_support_status','scope_axes','source_table','empty_or_null_label']
    with (out/'question_classifications.csv').open('w',newline='',encoding='utf-8') as fh:
        w=csv.DictWriter(fh,fieldnames=row_fields);w.writeheader()
        for r in rows:
            meta=metadata[r['question_id']]
            w.writerow({'question_id':r['question_id'],'released_split':r['split'],
                'patient_fhir_id':r['patient_fhir_id'],'primary_operation':primary_operation(r['template']),
                'candidate_support_status':candidate_status(r,meta),
                'scope_axes':'|'.join(sorted(scope_axes(r,meta))),
                'source_table':r['main_table_name'],'empty_or_null_label':r['true_answer'] in EMPTY_ENCODINGS})
    print(json.dumps({k:stats[k] for k in ('overall','primary_operations','candidate_support_status','scope_axes_question_counts','companion_csvs')},indent=2))

if __name__ == '__main__': main()
