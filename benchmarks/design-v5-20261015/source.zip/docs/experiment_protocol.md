# Experiment and reporting protocol

**Status: proposed; no experiments have been run under this protocol.** This document specifies the experiments to implement after an LLM API is available. Counts and limits below are planning quantities, not results. The first implementation milestone is a reproducible pipeline that runs the three principal systems, scores their outputs, and saves the evidence needed for the report.

## 1. Research question and controlled comparison

The primary question is whether separate retrieval, analysis, and source-grounded verification with one targeted repair improves patient-record QA over a capable single agent under the same per-question ceilings. Compare **S versus T** as the primary pair. D establishes a simpler reference point.

| System | Behavior |
| --- | --- |
| D: direct | One response from the shared starting packet; no live tools or revision. |
| S: single agent | One context can retrieve, calculate, check original fields, and revise once. |
| T: verified team | Separate retrieval, analysis, and verification contexts; a fixed controller routes at most one repair and one recheck. |

Use the same base model across all roles for the primary experiment. All systems receive the same question, patient identifier, reference-time assumptions, starting packet, and answer/evidence schema. S and T share tools, schemas, deterministic checks, and access to the intact store. Tool improvements apply to both.

FHIR-AgentBench documents retrieval and interpretation failures, including encounter filtering and resource-reference traversal. Its results motivate a strong executable single-agent baseline, without establishing that additional agents improve current models. [FHIR-AgentBench](https://arxiv.org/html/2509.19319v1)

Independent verification is motivated by CoVe, while CRITIC supports external feedback and documents harmful revisions. These are reasons to test the design, not guarantees of improvement on FHIR. [CoVe](https://aclanthology.org/2024.findings-acl.212/), [CRITIC](https://arxiv.org/html/2305.11738v3)

## 2. Stages, counts, and decisions

Run the stages in order. Do not sweep every architecture across every model.

| Stage | Planned matrix | Runs | Decision supported |
| --- | --- | ---: | --- |
| Pilot | 20 development questions × D/S/T | 60 | Does execution, scoring, evidence capture, and accounting work? |
| Architecture development | 50 development questions × five variants below | 250 | Which components merit the final team design? |
| Optional model screen | 20 development questions × three candidates × S/T | 120 | Which accessible model can execute both principal systems reliably? |
| Frozen evaluation | 300 previously unused held-out questions × D/S/T | 900 | Does the selected design improve held-out performance? |
| Omission experiment | 50 eligible held-out questions × S/T × intact/omitted | 200 | Does verification help recover initially missing evidence? |

The five architecture variants are S; retrieval→analysis (RA); RA with deterministic checks and one routed repair; retrieval→analysis→verification without repair; and retrieval→analysis→verification with one repair. Deterministic checks validate explicit evidence and operations; they do not replace an LLM's interpretation of the question. Keep check definitions shared and record which checks each variant invokes.

During the pilot, inspect malformed outputs, tool failures, budget exhaustion, and scoring disagreements before pursuing accuracy. Architecture development tests specialization, checking, and repair. The optional model screen uses the same questions and frozen provisional prompts for every candidate; it is a small feasibility screen, not a ranking of general model quality. Candidate identifiers and selection rationale belong in the implementation plan and run configuration.

These stages total **1,410 planned runs**, or **1,530 with the optional screen**, excluding debugging and separately declared repeats. Development sizes may change before the freeze; document the reason and updated counts. The new 300-question evaluation remains untouched by development. If the pilot fails, fix the pipeline and rerun development instead of consuming held-out questions.

## 3. Split discipline and freeze

Create patient-disjoint development and test partitions before model experimentation. Reserve the proposal's illustrative patients, upstream prompt-example patients, and any patient whose answers are manually used to design prompts for development. A proposed starting allocation is 30 development patients and 64 test patients: sort the remaining patient IDs, shuffle with Python `random.Random(5106).shuffle`, fill the development allocation after the reserved patients, and assign the rest to test. Save the reserved IDs, Python version, algorithm, and resulting manifest, not only the seed. Finalize this only after checking eligible-question coverage. Draw pilot, architecture, and model-screen questions only from development patients; the 20 pilot questions may be a documented subset of the 50 development questions, with fresh runs at each stage.

Select 300 questions from test patients using frozen family quotas. A feasible starting target to investigate is 80 lookup/count, 180 temporal-selection, and 40 numerical-aggregation questions; the narrow candidate pool has far fewer scalar aggregates than temporal questions. Aim for at most ten questions per patient and represent each supported operation. Preserve each family's empty-answer proportion where feasible. If coverage cannot satisfy these targets, adjust the quotas or cohort size using metadata before the freeze and disclose the change. Do not remove failed questions after running agents. Record question and patient counts by split. This stratified subset does not estimate the full release's natural prevalence.

Classify each question offline by operation, answer type, clinical concept/resource path, temporal scope, encounter scope, and empty/nonempty reference outcome. Keep broad-family and subtype counts visible. Stratify the held-out sample over the supported families and preserve empty cases. Template overlap is allowed but must be reported: patient separation does not establish generalization to unseen linguistic templates.

Before evaluation, freeze data checksums, split manifests, question eligibility, scorer rules, prompts, tool schemas, packet construction, role-model map, model settings, budgets, and analysis scripts. Hash the complete resolved configuration. Never change a scorer or prompt after inspecting test results and silently retain the same experiment name. A necessary correction creates a new protocol version and clearly labeled rerun.

Only the offline harness can read `true_answer`, `true_fhir_ids`, SQL, templates, and annotation-derived categories. Agent task objects contain an allowlist of question, patient identifier, assumptions, and permitted packet data. These restrictions apply to tool files and execution workspaces as well as prompt text. Gold metadata must not guide live retrieval or verification.

## 4. Budget and execution controls

Tentative **per-question aggregate ceilings**, to calibrate on development data:

| Resource | Ceiling |
| --- | ---: |
| Input tokens, including repeated context | 64,000 |
| Output tokens, including billed reasoning where exposed | 8,192 |
| Logical tool calls | 24 |
| Model calls | 16 |
| End-to-end wall time | 180 seconds |

These ceilings cover the entire system, including verifier, repair, and recheck. Reserve sufficient headroom for a repair within them. They are not per-agent allowances. Equal caps do not imply equal usage; actual consumption and exhaustion rates are reported. D naturally uses fewer resources.

Define logical tool-call counting in the tool contract before freezing: each agent-requested tool invocation counts once; automatic pagination and batched resource fetching also record physical requests, records, and bytes. Fix pagination, batch, and response-size limits across S/T. All issued model requests, including retries, consume the model-call ceiling and contribute their observed usage. If a provider omits token details, mark them unavailable rather than zero.

Use identical concurrency, timeout, retry, and cache policies across compared systems. Randomize or interleave paired execution order to reduce time-of-day service effects. Allow bounded infrastructure recovery and one schema-formatting recovery per malformed role output, all within the common limits. Formatting recovery is distinct from the single semantic repair; neither permits best-of-N answer selection. Preserve every failed attempt and its billed cost. Across models, equal token ceilings are not equal computation; compare actual cost and latency as well.

## 5. Strict scoring and evidence checks

Score a structured answer separately from its explanatory prose. Parse references and predictions into declared types. Missing output, terminal unrecovered tool failure, timeout, invalid terminal schema, and unsupported abstention count as incorrect in primary end-to-end accuracy. A recovered intermediate tool error does not invalidate a correct final answer; its time and cost still count. Also report separate failure rates and conditional accuracy among completed runs, clearly labeled.

| Answer kind | Frozen scoring rule |
| --- | --- |
| Boolean/existence | Canonical true/false; normalize dataset encodings only when the question's type warrants it. |
| Count | Exact integer; zero is an answered count. |
| Quantity | Compare canonical unit and numeric value with quantity-specific tolerances fixed on development data. |
| Timestamp/date | Compare at requested precision using documented timezone and reference-time rules. |
| Category | Apply a versioned alias/case/whitespace map; no unconstrained semantic matching. |
| Set/list | Normalize members; order matters only when requested. Define duplicate handling in advance. |

Do not treat `false`, `0`, an empty set, unknown information, and execution failure as interchangeable. Preserve typed empty outcomes. An abstention is incorrect when an answer exists. For a legitimate empty outcome, require the appropriate typed answer; assess supporting search separately. Do not use permissive numeric tolerances or date matching that hides the measurement-time versus issue-time error.

Evidence checks resolve resource IDs, field paths, cited values, units, patient links, encounter links, and time constraints against the original store. For calculations, save the operation and contributing resource IDs and independently recompute where supported. Separate citation validity from semantic support and completeness: correct cited fields cannot establish that an earlier event or larger value was not omitted.

Report answer accuracy, typed-empty accuracy, valid-evidence fraction, answer-and-evidence success, and retrieval precision/recall. State the denominator for each. Benchmark ID overlap is diagnostic; it may penalize useful dependency records and cannot alone prove a complete search. Keep the existing LLM-judge score as a separately labeled comparability measure, with model/prompt version and cost, if access permits.

Use these explicit metric definitions in the scorer specification:

- Answer accuracy is correct terminal answers divided by all scheduled questions; typed-empty accuracy uses the adjudicated empty-reference subset.
- Valid-evidence fraction is valid cited field claims divided by all cited field claims. Report citation coverage separately; a run with no citations has undefined citation validity, not perfect evidence. For answer-and-evidence success, require a correct answer and the evidence appropriate to its type: supported claims/contributors for positive answers, or a validated complete scoped search for a negative/empty answer.
- On rows with nonempty gold ID sets, fractional recall is `|retrieved ∩ gold| / |gold|`; fetched-resource precision is `|retrieved ∩ gold| / |retrieved|`. Use `(resourceType, id)` sets, report macro means and eligible counts, and report empty-gold/no-retrieval cases separately. Missing retrieved evidence yields zero recall where gold exists. Cited-resource precision is a separate statistic over citations, not all fetched records.
- Helpful-repair rate is wrong drafts made correct divided by wrong drafts that received semantic repair; harmful-revision rate is correct drafts made wrong divided by correct drafts that received semantic repair. Also show the complete draft/final transition counts and net accuracy change, including runs with no repair. Zero denominators are reported as not applicable.

Two teammates independently audit 30–50 outputs, blinded to system identity. Sample across families, empty cases, repairs, and scorer disagreements; record selection and adjudication. Targeted audits diagnose problems but do not provide an unbiased overall error prevalence estimate.

## 6. Omission controls and repair outcomes

Target 50 eligible questions from the frozen held-out cohort. The offline harness must establish that the intact packet yields the full-store/reference answer, that a removable resource occurs in that packet, and that removing it changes the derived answer or makes it indeterminate. Exclude redundant evidence, already-inadequate intact packets, absent resources, and cases whose eligibility cannot be established. Freeze the eligibility rule before inspecting system outcomes; if fewer than 50 qualify, report the smaller sample rather than manufacture cases or weaken the rule. Save the eligibility reason, omitted ID, and before/after derivations in an offline-only manifest.

The complete store remains intact. Neither system receives the omitted ID, a missing-item marker, nor a harness explanation. Use identical packet construction and omissions for S/T. Do not refill the gap with another record; record resulting packet size so the perturbation's scope is visible. Validate that agent-visible metadata does not reveal the removed resource.

Run **fresh paired intact and omitted trials** for both systems, totaling 200 runs. Do not substitute ordinary-evaluation intact outputs: fresh trials keep ordering, settings, and repetition policy aligned. Label this as resilience to incomplete initial context, not corruption or permanent loss of the source store.

Report paired accuracy drop, omitted-resource retrieval rate, and correct-answer recovery rate. Retrieving the omitted record without producing the correct answer is not successful answer recovery. Record the stage and role that first recovers it: ordinary retrieval may restore it before any draft or verification. Report whole-pipeline resilience separately from recovery initiated by verifier feedback; the omission experiment alone does not attribute gains to verification. Track draft→final wrong/right transitions, helpful repairs, harmful revisions, and failure to resolve a flagged issue; preserve cases where the verifier incorrectly accepts a draft.

## 7. Reproducible event and result records

Use immutable JSONL events and one terminal result per run. Proposed repository-relative layout: `configs/experiments/`, `manifests/`, `runs/<experiment_id>/`, and `reports/`. Store large payloads as content-addressed artifacts, with paths and hashes in events. These are planned conventions, not claims that a logging implementation exists.

The stable run key contains **configuration hash, data version, split version, question ID, system ID, role-model map, packet condition, and repeat index**. Keep **attempt ID separate** so retries remain traceable without becoming new experimental observations. Include protocol version and code commit in the manifest. Never overwrite an earlier attempt or silently select its best answer.

| Record | Required fields |
| --- | --- |
| Run manifest | Experiment/run IDs; complete key; code commit; resolved configuration; data and split hashes; question/packet hashes; provider/model identifiers and settings; tool/schema/prompt hashes; budget; execution environment; start/end time. |
| Event envelope | Run/attempt IDs; event ID; monotonic sequence; timestamp; elapsed time; role; stage; event kind; parent/correlation ID; status. |
| Model request/result | Logical call and provider request IDs; model/settings; input/output artifact references; latency; token breakdown; finish reason; retry/error details; price snapshot and billed/estimated cost status. |
| Tool request/result | Tool/version; validated arguments; patient/encounter scope; result artifact/hash; returned IDs/counts; pagination/completeness flags; truncation; execution code/output references; duration; error. |
| Agent handoff | Source/destination; task contract; evidence artifact references; proposed answer/operation; explicit scope and limitations. |
| Verification/repair | Draft ID; each check and evidence; issue type; field/resource; responsible role; requested action; verdict; repair ID; revised draft ID; final disposition. |
| Terminal result | Typed draft/final answers; cited evidence; final status; budget use/exhaustion; aggregate observed costs; latency; successful and failed attempt references. |
| Offline evaluation | Scorer/version; gold reference/hash; typed correctness; evidence checks; retrieval metrics; repair transition; error taxonomy; human annotations/adjudication. |

Log observable messages, decisions, tool actions, and returned artifacts. Do not require hidden chain-of-thought. Store concise reason codes and executable operations for auditability. Separate agent-visible artifacts from offline labels; never place credentials in logs. Record cache hits and shared preprocessing cost rather than silently excluding them.

## 8. Analysis and report mapping

The primary estimand is question-weighted accuracy over the selected 300 questions: correct terminal answers divided by all scheduled questions. Compute paired S–T accuracy differences on those same questions. Form 95% confidence intervals using 10,000 bootstrap draws of **patient blocks**, retaining all sampled patients' questions and paired system outcomes and recomputing the ratio in each draw. Report patient counts. Equal-family macro accuracy and patient-weighted accuracy can be secondary, clearly distinguished from the primary measure. Do not treat questions from one patient or repeated trials as independent patients.

An optional variability check repeats a preselected 20-question held-out subset twice more for S/T: 80 additional runs, giving three total trials per system/question when combined with its ordinary run. Select the subset and aggregation rule before inspecting outcomes, report run-to-run agreement and accuracy spread, and do not count those repeats as 40 new questions. Architecture ablations and model screening are exploratory; the frozen S–T comparison is the primary inferential claim.

| Report output | Required logged data |
| --- | --- |
| Dataset/taxonomy table | Split manifests; patients; operator, scope, resource, answer-type and empty tags. |
| Main performance table | D/S/T accuracy, paired S–T difference/interval, evidence success, failures, sample counts. |
| Family breakdown plot | Per-question scores joined to frozen taxonomy; counts and uncertainty. |
| Architecture ablation table | Development variant configurations, paired scores, actual budgets; labeled development-only. |
| Accuracy–cost plot | Mean end-to-end accuracy and observed cost/tokens per question, including retries. |
| Latency plot/table | End-to-end median/p95; timeout rate; common concurrency settings. |
| Recovery plot | Fresh intact/omitted pairs; accuracy loss; omitted-ID retrieval and answer recovery. |
| Repair transition table | Draft/final correctness, verifier verdicts, issue types, repair targets. |
| Qualitative case study | Original fields, proposed operation, detected issue, repair, final answer, independent score. |

Report negative and inconclusive outcomes. Better citations without better answers establish a traceability benefit; extra cost without a reliable S–T gain favors the simpler system for this setting. Conclusions apply to this supported question subset and small deidentified cohort, not clinical effectiveness.
