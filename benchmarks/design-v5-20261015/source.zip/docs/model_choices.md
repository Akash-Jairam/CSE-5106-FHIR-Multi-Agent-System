# Model choices and estimated costs

Prepared October 7, 2026. Model selection is a team decision. No account access, endpoint compatibility, speed, or task accuracy has been tested. Prices below are the retrieved standard API rates, not measured project costs; recheck them before running experiments.

**Recommendation:** build a provider-independent adapter, start the first live pilot with a pinned GPT-5.4 Mini snapshot if available, and screen GPT-6 Luna as the cheaper alternative. Use GPT-5.4 as a larger-model comparison only on development data initially. If cross-provider robustness matters more than a size comparison, substitute Gemini 3.8 Flash for that third screening slot. Run the final architecture comparison with one selected model across every role.

This recommendation prioritizes an interpretable experiment and a manageable integration path. It does not imply that the older Mini model is more capable than Luna on this task. The relevant unknowns are valid tool use, structured evidence quality, temporal/encounter reasoning, and cost per correct answer on our development questions.

## Shortlist

| Candidate | Why consider it | What must be checked | Standard input / output per million tokens |
| --- | --- | --- | --- |
| GPT-5.4 Mini, `gpt-5.4-mini-2026-03-17` | Suggested first integration target; explicit dated snapshot, function calling and structured outputs; relatively low price | Existing LiteLLM pin may need updating; verify full tool round trips, usage, and output limits | $0.75 / $4.50 |
| GPT-6 Luna, `gpt-6-luna` | Strong cost-saving candidate for repeated experiments | Reasoning with function calling requires the Responses API; Chat Completions tool calls require reasoning effort `none`. Listed alias has no dated snapshot on the fetched page | $0.10 / $0.50 |
| GPT-5.4, `gpt-5.4-2026-03-05` | Larger-model quality comparison with a dated snapshot; tests whether stronger inference changes the need for verification | Higher spending; quality advantage on this dataset is unmeasured | $2.50 / $15.00 |
| Gemini 3.8 Flash, `gemini-3.8-flash` | Alternative provider with tool calling and structured outputs; useful replication candidate | Native message/tool conventions, thinking settings, usage accounting, and SDK compatibility | $0.75 / $3.75 through December 31, 2026 |

Capabilities and prices are supported by the official [GPT-5.4 Mini](https://developers.openai.com/api/docs/models/gpt-5.4-mini), [GPT-6 Luna](https://developers.openai.com/api/docs/models/gpt-6-luna), and [GPT-5.4](https://developers.openai.com/api/docs/models/gpt-5.4) pages, plus [Gemini 3.8 Flash capabilities](https://ai.google.dev/gemini-api/docs/models/gemini-3.8-flash) and [Gemini API pricing](https://ai.google.dev/gemini-api/docs/pricing). Gemini's listed standard rates rise to $1.50 input / $7.50 output per million on January 1, 2027. Do not assume the course deadline falls before that change.

The starter scripts mention `o4-mini` and Gemini 2.5 Flash. Treat them as historical reproducibility options rather than automatic defaults. Google's current [Gemini 2.5 Flash page](https://ai.google.dev/gemini-api/docs/models/gemini-2.5-flash) says access is restricted to prior active users. An example in the README does not establish current account access.

Avoid a self-hosted model for the first milestone unless the team already has a suitable GPU server. It introduces serving, memory, quantization, and tool-parser variables. A later open-weight comparison should record the exact checkpoint, quantization, hardware, serving version, and decoding configuration. Running the base Qwen model is not equivalent to reproducing the trained model in the [2026 FHIR reinforcement-learning paper](https://arxiv.org/abs/2605.14126).

## How to make the final choice

First run a small API capability check after access exists. Confirm a structured response, a FHIR-tool request/result exchange, an operation-tool exchange, malformed-output handling, and usage reporting. Update and lock dependencies only after these checks. The current wrapper treats only `o4-mini` as a special reasoning model; do not extend it with a growing list of guesses. Use explicit provider/model capabilities and request parameters.

Then use the same 20 development questions for three candidates under both the strong single agent and the verified team: 120 runs. Candidates should span lookup/count, temporal selection, aggregation, and empty answers, with encounter-scope and time-boundary cases. The 20-question screen detects incompatibility and large differences; it cannot establish a reliable ranking from a one-question advantage.

Select using these criteria, in order:

1. **Functional reliability:** no unsupported endpoint behavior, complete accounting, and a proposed minimum 95% schema-valid terminal responses. A schema-valid wrong answer still counts as wrong.
2. **Task quality:** typed accuracy and evidence checks, especially time/scope errors and wrong-to-right versus right-to-wrong repair. Inspect failures rather than trusting a single average.
3. **Efficiency:** actual dollars, input/output/reasoning tokens, tool use, median latency, and p95 latency. Compare cost per correct answer alongside accuracy so a cheap but unreliable model does not appear preferable.
4. **Reproducibility:** stable model identifiers, accessible endpoint, recorded settings, and manageable rate limits.

If the screen is close, keep the cheaper compatible candidate or confirm the finalists on the remaining development questions before freezing. Decide the practical accuracy loss the team is willing to trade for cost before viewing results. Do not select a model from the 300-question test set. If the test later motivates a change, report it as a new exploratory study with a new untouched evaluation set.

Reasoning effort is an experimental setting. Start with a documented low or medium setting appropriate to the endpoint; record it and hold it fixed across architectures within a model. Equal labels across providers do not imply equal computation. Use temperature zero where supported, but do not describe this as deterministic inference. A later repeated subset measures variability.

Do not initially assign a cheap retriever and expensive verifier. That changes both architecture and model allocation. Once the same-model comparison is complete, a mixed-model team can be a separate cost experiment against a similarly budgeted single agent.

## Transparent cost estimate

For each question, sum usage over every role, check, repair, and retry. A simple uncached estimate is:

`cost = input_tokens / 1,000,000 × input_rate + output_tokens / 1,000,000 × output_rate`

The example below assumes **30,000 total input tokens and 4,000 total billed output tokens per question across the entire system**, including reasoning tokens when billed as output. This is a planning scenario, not a prediction. Repeated context can make a multi-agent system exceed it.

| Model | Example cost per question | 60-run pilot if all runs averaged this usage | 1,100 core evaluation runs at this average |
| --- | ---: | ---: | ---: |
| GPT-6 Luna | $0.0050 | $0.30 | $5.50 |
| GPT-5.4 Mini | $0.0405 | $2.43 | $44.55 |
| GPT-5.4 | $0.1350 | $8.10 | $148.50 |
| Gemini 3.8 Flash at 2026 rates | $0.0375 | $2.25 | $41.25 |

The 1,100-run protocol is 900 ordinary runs and 200 fresh paired omission runs. Actual direct-baseline usage should usually differ from team usage, so multiplying one average is only a budgeting illustration. Use separate measured averages per system after the pilot.

At the protocol's tentative ceilings of 64,000 aggregate input and 8,192 aggregate output tokens, the same 1,100 runs would cost about $11.55 for Luna, $93.35 for Mini, $311.17 for GPT-5.4, or $86.59 for Gemini at the listed 2026 rates. These are token-cost envelopes under enforced accounting, not guarantees about an API bill. Unknown retry charges, other services, and later price changes require separate accounting.

At the example average, the 60-run Mini pilot plus 250 Mini architecture-development runs would cost about $12.56. Screening Luna, Mini, and GPT-5.4 for 40 runs each adds about $7.22. Thus the proposed development sequence is about $19.78 in this scenario, before optional confirmations, infrastructure, and judging. Reserve approximately **$30–50 for development**, then use measured usage to decide the evaluation budget. For a Mini-based full study, **$100–150 total model budget** is a reasonable initial planning allowance for this sequence and contingency, subject to the measured caps and actual spending ledger. A predominantly GPT-5.4 study needs a larger allowance.

These estimates exclude GCP hosting, a GPU server, and the optional official LLM judge. A local indexed store avoids recurring cloud-store costs. Deterministic primary scoring consumes no model tokens. Price the official judge separately after measuring its prompt and output usage on a small sample. Do not rely on free tiers or discounted batch processing to meet the budget.

## Decisions for the team

| Decision | Suggested default | Reason to choose differently |
| --- | --- | --- |
| First live integration model | Pinned GPT-5.4 Mini | Choose Luna if minimizing spend justifies implementing its appropriate endpoint immediately |
| Three-model screen | Luna, Mini, GPT-5.4 | Substitute Gemini for GPT-5.4 when cross-provider evidence is the priority or OpenAI access is limited |
| Primary study model | Cheapest candidate with acceptable development quality and reliable tools | Choose the larger model if cheaper candidates fail core scope/time tasks |
| First budget checkpoint | $30–50 development allowance | Lower it by running the pilot first and postponing optional screens |
| Model roles | Same model and settings throughout | Mixed roles only as a separately labeled later experiment |

No purchasing or API execution is part of this planning deliverable. The implementation can progress through deterministic data, tool, evaluator, and controller work before these choices are finalized.
