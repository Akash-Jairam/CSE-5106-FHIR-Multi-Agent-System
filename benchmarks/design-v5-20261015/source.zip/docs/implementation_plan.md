# FHIR multi agent implementation plan

Prepared October 7, 2026. This is a plan through the first evaluated backend, followed by a defined path to the proposal's experiments. No live model runs or performance results are claimed. Model access is currently unavailable; model and spending decisions remain with the team.

Build a small, observable retrieval → analysis → verification system with one targeted repair. First make the data, tools, and evaluator trustworthy; then compare this team with an equally equipped single agent. Use a fixed controller, separate role contexts, a shared immutable record store, and structured messages. A successful first milestone is a reproducible 20-question pilot with complete traces and interpretable failures, even if the team does not outperform the baseline.

Read this document first. The supporting documents supply [question definitions and dataset counts](question_taxonomy.md), [model choices and cost estimates](model_choices.md), [experiment and recording rules](experiment_protocol.md), and [specific starter-code issues](repository_audit.md).

## Research question and scope

The core question is: **Does field-linked verification with bounded targeted repair improve factual patient-record QA and recovery from incomplete starting evidence, compared with a single agent using the same tools and resource limits?**

This preserves the proposal's contribution. Multi-agent clinical QA already exists: [EHRNavigator](https://arxiv.org/abs/2601.10020) coordinates specialized components. [FHIR-AgentBench](https://proceedings.mlr.press/v297/lee26a.html) already studies retrieval, executable reasoning, and repeated tool use. Our experiment concerns checking wrong fields, encounter scope, calculations, and missing evidence even when a program executes successfully. More agents are a hypothesis to test, not a promised improvement.

The first backend supports one patient and one self-contained question at a time. Start with Patient, Encounter, and numerical Observation records. Support attribute lookup, recorded-event existence, hospital-admission counts, counts of matching observations, first/last qualifying observation or encounter, threshold filtering, and min/max/mean of compatible measurements. Observation counts require an explicit event-identity and deduplication rule; ICU-stay variants require a separately checked encounter mapping within this same resource scope. Temporal and encounter constraints apply across these operations. Include empty-result cases within supported operations from the beginning.

Defer medication dose calculations, complex reference chains, grouped trends, two-measurement changes/comparisons, elapsed-time questions, notes, follow-up dialogue, cohort questions, diagnosis, treatment recommendations, and a user interface. These are scope decisions for the first milestone, not claims that FHIR cannot represent them. Broadening to Condition, Procedure, and medication resources should be a separately versioned extension after the initial pilot.

The professor's classification request should be answered with operation + answer type + scope + resource dependencies, rather than three broad labels alone. The [taxonomy](question_taxonomy.md) provides the full mapping and report-ready wording.

## What exists and what must be established

The supplied repository has 2,931 QA rows for 94 patients and 76 templates, five single-agent strategies, a LiteLLM wrapper, a tool registry, a GCP FHIR client, and an LLM-based evaluator. Its `multi_turn` classes are iterative single agents. Separate role contexts and a team protocol still need to be built.

The checkout contains QA and mapping CSVs, but no raw patient FHIR store was found. A question CSV is not the clinical evidence database. Acquire and fingerprint the [MIMIC-IV FHIR demo version 2.1.0](https://physionet.org/content/mimic-iv-fhir-demo/2.1.0/), preserve raw resources, and verify record counts and reference resolution before model evaluation. The public demo contains 100 patients; the QA file covers a subset.

The audit identifies changes that must precede experiments: correct resource-ID queries and pagination, union repeated retrieval results rather than overwriting them, isolate Python execution, preserve full traces, separate run identities, and replace permissive primary scoring. Two released test questions also appear verbatim in existing prompt examples. Reserve the proposal/example patients for development and use new patient-disjoint evaluation manifests. Do not reuse the starter prompts as a clean unseen-question baseline without addressing their examples.

## Data and tool design

### A reproducible store

Use a small `ResourceStore` interface so agent logic does not depend on deployment:

| Operation | Required behavior |
| --- | --- |
| Read one resource | Exact resource type and ID; return original JSON or a typed not-found result |
| Search patient records | Patient fixed by the task; explicit resource type, code, encounter, time range, and pagination |
| Follow references | Resolve linked encounter and permitted terminology resources; check patient ownership where applicable |
| Read fields | Resolve explicit JSON pointers against immutable source JSON |
| Describe capabilities | List supported filters and fields; unsupported filters produce errors rather than silently broad searches |

Recommended default, given the absent local store: index downloaded NDJSON in SQLite, retain each original JSON object, and expose the narrow tool interface above. SQL is an internal index implementation; agents do not receive benchmark SQL or direct access to QA tables. This is a local resource backend, not a claim to implement a complete FHIR server.

If the team already has the documented GCP store, reuse it through the same interface for the first run instead of maintaining two backends immediately. Freeze one backend for each comparison. A later local/GCP parity check should compare sorted resource-ID sets and field values for representative searches. Do not change backend while attributing a difference to architecture.

FHIR searches must use supported resource-specific parameters. Standard ID search uses `_id`, or a direct read at `ResourceType/id`; a generic `patient` query is not appropriate for every resource. Follow every page or report incomplete retrieval. These semantics come from [FHIR R4 search](https://hl7.org/fhir/R4/search.html).

Each tool result should carry `query_id`, normalized filters, returned IDs, dataset version, `complete`, pagination state, and any truncation/error. An error is never an empty result. A capped response cannot establish that no matching records exist.

For the common starting packet, begin with an 8,000-token evidence allowance measured using one fixed reference tokenizer. Match question terms to resource labels/codes using a development-reviewed synonym map; rank by lexical match with a stable resource-type/ID tie-break. Reserve space for the patient and linked encounter context, then append whole resource projections until the cap. Preserve IDs and field names, disclose truncation equally, and keep the complete store searchable. Freeze the ranking, projection fields, tokenizer, and cap on development data; never use gold IDs or answers to improve an ordinary starting packet.

### Time, units, and encounters

Write one shared semantic policy before prompts:

- Resolve relative dates using the task's supplied reference time, never today's date. Preserve the original assumption text and a structured interpretation.
- Preserve source offsets; compare timezone-aware instants. Specify how offset-free benchmark timestamps map to the source's local time before scoring. Never silently discard offsets.
- Prefer the event's relevant clinical time. For observations, `effectiveDateTime` or the supported `effective[x]` representation differs from `issued`. The first milestone may explicitly reject unsupported effective-time variants.
- Define hospital admissions from Encounter class/type and hierarchy in this dataset. Count distinct hospital episodes, not every ICU/transfer child encounter. Resolve “latest admission” before retrieving its measurements.
- Preserve strict inequalities: “below 21” means `< 21`. Define calendar-window boundaries, ties, and requested timestamp precision in the policy.
- Aggregate only compatible codes and units. Use a small, reviewed unit-conversion table where necessary; return a limitation for unsupported combinations. Do not merge lab and chart concepts only because their labels resemble one another.

The dataset's `assumption` strings include terminology and query-derived hints as well as reference times. Keep them identical across systems for the main benchmark-aligned experiment, and describe the setting as QA with supplied assumptions. An unassisted natural-language product would need its own terminology and ambiguity handling evaluation.

### Executable operations and provenance

For the narrow initial scope, prefer a validated operation plan interpreted by ordinary Python: filter, project, distinct count, sort/select, min, max, and mean. It is easier to audit and contain than unrestricted generated code. Offer the same operation tool to the single agent and team. Retain a separately labeled upstream free-code baseline only if needed for benchmark comparison.

If generated Python is included, run it in a separate restricted worker with a real timeout, resource limits, no network, no credentials, and access only to the current question's retrieved data. The existing `exec` call and unused timeout parameter are insufficient. Its worker must not be able to read the repository's gold CSV. Reject unsupported operations explicitly.

An operation result should include the selected IDs, contributing IDs, extracted fields, operation parameters, and result. Large record collections live in a store under immutable handles; send concise field projections to agents and allow full reads. Preserve the complete objects in logs. Text truncation is a display choice and must not silently become evidence deletion.

## Agent architecture

Use LangGraph for state transitions and conditional routing, with ordinary Python tools and typed message validation. Its [Graph API](https://docs.langchain.com/oss/python/langgraph/graph-api) supports explicit state, nodes, and edges. This satisfies the proposal's intent to reuse orchestration infrastructure while keeping the team protocol under our control. Do not add a manager LLM to route a three-stage fixed workflow.

```mermaid
flowchart TD
    I[Question, patient ID, assumptions] --> P[Deterministic starting packet]
    P --> R[Retrieval agent]
    R --> A[Analysis agent]
    A --> C[Deterministic evidence checks]
    C --> V[Verification agent in fresh context]
    V -->|Checks pass| F[Answer and evidence]
    V -->|Retrieval issue and repair available| R
    V -->|Analysis issue and repair available| A
    V -->|Unresolved or budget exhausted| L[Explicit evidence limitation]
    S[(Immutable FHIR store)] --- R
    S --- C
    S --- V
    F --> E[Offline evaluator with hidden labels]
    L --> E
```

The controller increments one global repair counter before routing backward. A retrieval repair always reruns analysis and verification. An analysis repair reruns verification. A second failure terminates with a limitation; it cannot create another loop.

| Component | Input and responsibility | Output |
| --- | --- | --- |
| Starting packet builder | Deterministic concept/label matching within the patient, linked encounter context, fixed ordering and token cap; no labels | Same packet and packet hash for all systems |
| Retrieval agent | Question, assumptions, packet, supported tool schema; select concept, patient/encounter/time scope and acquire evidence | Retrieval bundle with resource handles, scope, queries, and completeness information |
| Analysis agent | Original question and assumptions plus retrieval bundle; validate interpretation and execute operation | Typed draft answer, evidence, calculation specification, limitations |
| Deterministic checker | Original resources plus draft; verify paths, values, ownership, operation execution | Check records and explicit failures; no language-model judgment of question meaning |
| Verification agent | Original question, assumptions, draft answer, formal operation, cited fields, retrieval metadata, checker results | Pass, targeted repair request, or insufficient evidence |
| Fixed controller | Role outputs, budget ledger, repair counter | Route transitions, persist events, enforce stopping |

Use the same model and settings for all three roles in the primary architecture experiment. Each role has separate messages and role-specific tool permissions. Shared state contains artifacts, not a shared conversation history. The verifier receives no analyst reasoning transcript. It can reconstruct the intended operation from the question before comparing with the proposed operation, reducing dependence on the draft.

The verifier must check two different things. **Validity** asks whether a cited record, path, value, and scope are correct. **Completeness** asks whether enough qualifying records were considered to justify a first/last event, count, maximum, or empty answer. For the latter, independently query the relevant scope and inspect pagination/filter metadata. An original-source read may use an immutable raw-data cache; it must not merely read the analyst's summary.

Fresh-context checks are motivated by [Chain-of-Verification](https://aclanthology.org/2024.findings-acl.212/), and tool-grounded correction by [CRITIC](https://arxiv.org/abs/2305.11738). These papers do not establish that this FHIR team will improve. Shared-model errors and harmful repairs must be measured.

### Structured contracts

Define these contracts before implementing role prompts. Use schema validation at every boundary; one bounded formatting retry consumes the common budget and is logged separately from a semantic repair.

| Contract | Required fields |
| --- | --- |
| Task input | Question ID, question, patient FHIR ID, original assumptions, parsed reference time, dataset version |
| Retrieval bundle | Scope, query records, resource handles/IDs, field projections, completeness flags, unresolved references |
| Answer | Status, answer type, typed value, unit/precision where relevant, evidence claims, operation specification, limitations |
| Evidence claim | Resource type and ID, JSON pointer, source value, contribution to answer; linked patient/encounter support |
| Operation | Operator, field paths, filters, temporal policy, distinct key, ordering/tie policy, contributing IDs, result |
| Verification result | Check outcomes, verdict, issue list, target role, corrective action, independently retrieved evidence |
| Controller state | Run ID, role artifacts, draft versions, repair count, budgets used/remaining, terminal status |

Use answer statuses `answered`, `empty_result`, `insufficient_evidence`, and `unsupported`. Valid `0` and `false` are `answered`. Execution errors and timeouts are separate run statuses. Empty results need a successfully completed search of the relevant record scope; they do not prove that a clinical event never occurred outside the dataset.

Issue codes should include wrong patient, wrong encounter, wrong concept, wrong time field, wrong time boundary, missing records, invalid citation, unit mismatch, incorrect operation, and arithmetic error. Route scope/concept/missing-record issues to retrieval, and field/operation/arithmetic issues to analysis. If both occur, repair retrieval first and rerun downstream analysis within the same single repair cycle.

### Worked acceptance example

For the proposal's respiratory-rate question, retrieval identifies the patient, date window, respiratory-rate concept, and relevant observations. Analysis filters values `<21` and selects the earliest measurement time. Its supporting record is `Observation/5f77d8be-c363-502c-8031-b0e3b96ace3c`, with rate 20 and the proposal's measurement timestamp 2186-09-15 18:00.

If the draft instead uses the record's 18:21 issue time, verification emits `wrong_time_field`, targets analysis, and requests chronological selection using measurement time. The controller allows one correction and checks again. This is a development fixture from the proposal, not a held-out result or a newly confirmed raw-record computation.

## Implementation sequence and completion gates

These are dependency-ordered work packages. For three students, a two-to-three-week first-prototype effort is a planning estimate, not a deadline commitment. Data/backend setup can change it. Model access gates only the live-run phase.

| Package | Work | Completion evidence |
| --- | --- | --- |
| 1. Dataset and task contract | Download/version raw FHIR; review 76 template labels; create supported-question manifest; normalize references safely; reserve exposed patients; patient split | Dataset hashes, counts, no patient overlap, supported/excluded reasons, review of representative answers |
| 2. Tools and evaluator | ResourceStore, exact reads, paginated search, encounter/time/unit policy, operation executor, typed scorer, field checks | Meaningful fixtures for pagination, unions, admission hierarchy, timestamp confusion, strict thresholds, missing/empty/zero, unit mismatch |
| 3. Runner and recording | Separate actor input from evaluator labels; config-based run identities; budget and event logger; resumable outputs | Scripted fake-model runs exercise every branch; interrupted run resumes without mixing configurations |
| 4. Direct and strong single-agent baselines | Common packet/schema/tools; explicit draft, check, and one-revision opportunity for the single agent | Same task and packet hash; answer/evidence scored; full usage and draft/final artifacts preserved |
| 5. Three-role team | Separate contexts, validated messages, deterministic controller, one targeted repair, verifier source access | Missing-record and wrong-field fixtures route to the right role; correct drafts preserved; second failure terminates |
| 6. First live pilot | Once a provider is selected, run 20 development questions × 3 systems; inspect every failed case | 60 accounted-for runs; no silent drops; pilot table with accuracy, evidence, repair effects, cost, and latency |
| 7. Freeze candidate protocol | Fix implementation defects, use development-only architecture/model screens, set budgets and scoring | Versioned config/prompt/tool/split/scorer manifests and selected primary model |

Package 6 defines the first runnable-system milestone requested here. The later 300-question comparison and omission test are specified in the experiment protocol so recording is ready from the start. They should run only after package 7, not during debugging.

Suggested team ownership: one student owns data/store/semantic policy; one owns role prompts/controller/provider integration; one owns scoring/logging/experiment analysis. Assign names yourselves. Review another student's component, and jointly adjudicate question scope and reference-answer issues. Integration contracts and a daily shared fixture run matter more than assigning one student to each LLM role.

### Proposed repository integration

Keep the upstream strategies available as clearly labeled references. Add a project-specific package and runner, then optionally expose the new system in the existing strategy registry. The following paths are **planned, not implemented**:

```text
mas/
  schemas.py              # task, evidence, operations, role outputs
  controller.py           # LangGraph and one-repair routing
  agents/                 # retrieval, analysis, verification
  store/                  # ResourceStore and selected backend
  tools/                  # search, reads, operation executor, field checks
  models.py               # provider capabilities and usage normalization
  packet.py               # common deterministic starting evidence
  budgets.py              # common per-question limits
  logging.py              # complete events and artifact references
  scoring/                # typed answer and evidence evaluation
prompts/                  # versioned role and baseline prompts
configs/experiments/      # data, system, model, budgets, scorer versions
manifests/                # patient splits, question tags, packet conditions
run_experiment.py         # no gold fields in actor inputs
tests/fixtures/           # small synthetic cases plus reserved demo cases
```

Never expose `true_answer`, `true_fhir_ids`, SQL, templates, or omission metadata to an actor or its execution worker. Runtime inputs use an explicit allowlist. Template metadata is useful for offline classification and sampling, but using it to choose the correct tool or operation during an agent run would weaken the natural-language task.

## What can proceed before API access

All dataset review, raw-store setup, schemas, deterministic tools, typed scoring, split generation, budget accounting, and scripted-controller tests can be implemented without a model API. A fake-model adapter can replay valid messages, malformed messages, repair requests, and timeouts. This verifies engineering behavior only; it provides no evidence of language-model accuracy, cost, or latency.

The first live provider check should cover structured output, tool-call/result round trips, reasoning settings, usage fields, output limits, and retry behavior. Do not launch a benchmark just because a model returns a text response. The pinned starter LiteLLM version must be checked or updated for whichever current endpoints the team selects.

The final model decision, available provider account, total dollar ceiling, and whether a GCP store already exists remain team decisions. [Model choices](model_choices.md) offers defaults and alternatives; these do not block the API-independent work packages.

## Report evidence to collect from the first run

Preserve every draft, final answer, verification issue, repair target, tool query, resource ID set, field check, model call, failure status, and usage record. Save prompt/config versions and data hashes. Store raw outputs once, and regenerate tables from them rather than copying numbers manually. Detailed schemas and denominators are in the [experiment protocol](experiment_protocol.md).

The eventual report should distinguish answer accuracy, evidence validity, evidence completeness diagnostics, useful versus harmful repairs, and cost. Show results by operation and scope, not only an overall average. A team that adds citations without improving answer correctness has improved traceability; that is a different conclusion from better QA. A team that costs more without a meaningful gain supports choosing the single agent.

Add the May 2026 [FHIR tool-calling reinforcement-learning study](https://arxiv.org/abs/2605.14126) to related work: it demonstrates later progress on this benchmark under a trained-model protocol. Its reported validation performance is not directly comparable to our patient-disjoint, untrained subset study. Training, a polished UI, and broad clinical claims remain outside this first implementation milestone.
