"""Personal Azure adapter, enabled only by the local fhir-azure launcher."""
from dataclasses import dataclass, field
from datetime import datetime, timezone
from importlib import metadata
import json
import os
from pathlib import Path
import re
import sys
import threading
import time
from urllib.parse import urlsplit
import uuid

import yaml


@dataclass(frozen=True)
class AzureSettings:
    endpoint: str
    api_version: str
    deployment: str
    model: str
    max_completion_tokens: int
    reasoning_effort: str
    api_key: str = field(repr=False)

    @classmethod
    def load(cls, path):
        config = yaml.safe_load(Path(path).read_text()) or {}
        azure = config.get("AZURE_OPENAI", {})
        required = ["ENDPOINT", "API_VERSION", "DEPLOYMENT", "MODEL",
                    "MAX_COMPLETION_TOKENS", "REASONING_EFFORT"]
        missing = [name for name in required if azure.get(name) in (None, "")]
        if missing:
            raise ValueError("Missing Azure settings: " + ", ".join(missing))
        endpoint = str(azure["ENDPOINT"])
        url = urlsplit(endpoint)
        if (url.scheme != "https" or not url.hostname or url.username
                or url.password or url.query or url.fragment):
            raise ValueError("AZURE_OPENAI.ENDPOINT must be an HTTPS resource endpoint")
        maximum = int(azure["MAX_COMPLETION_TOKENS"])
        if maximum < 1:
            raise ValueError("MAX_COMPLETION_TOKENS must be positive")
        if azure["REASONING_EFFORT"] != "none":
            raise ValueError("This GPT-6 Luna Chat Completions tool setup requires REASONING_EFFORT: none")
        key = (os.getenv("AZURE_OPENAI_API_KEY") or os.getenv("AZURE_API_KEY")
               or azure.get("API_KEY") or "")
        return cls(endpoint, str(azure["API_VERSION"]), str(azure["DEPLOYMENT"]),
                   str(azure["MODEL"]), maximum, "none", str(key).strip())

    @property
    def key_present(self):
        return bool(self.api_key) and not self.api_key.lower().startswith(
            ("your-", "<", "paste", "replace"))

    def matches(self, model):
        return model in {self.model, self.deployment,
                         "azure/" + self.deployment}

    def public(self):
        return {"provider": "azure", "endpoint": self.endpoint,
                "api_version": self.api_version, "deployment": self.deployment,
                "model": self.model, "reasoning_effort": self.reasoning_effort,
                "max_completion_tokens": self.max_completion_tokens,
                "api_key_configured": self.key_present}


_settings = None
_client = None
_originals = None
_diagnostic_pid = None
_diagnostic_session = None
_diagnostic_counter = 0
_diagnostic_lock = threading.Lock()
_DIAGNOSTIC_ENV = "FHIR_LOCAL_AZURE_DIAGNOSTICS_DIR"
_REQUEST_ID_HEADERS = ("x-request-id", "x-ms-request-id", "apim-request-id")


def _class_metadata(value):
    if value is None:
        return None
    cls = type(value)
    def name(item):
        candidate = item.__module__ + "." + item.__qualname__
        return candidate if len(candidate) <= 200 and re.fullmatch(r"[A-Za-z0-9_.]+", candidate) else "unavailable"
    return {"class": name(cls), "mro": [name(item) for item in cls.__mro__[:16]]}


def _attribute(value, name):
    try:
        return getattr(value, name, None)
    except Exception:
        return None


def _fd_count():
    for directory in ("/proc/self/fd", "/dev/fd"):
        try:
            return sum(name.isdecimal() for name in os.listdir(directory))
        except OSError:
            pass
    return None


def _client_metadata(client):
    http = _attribute(client, "_client")
    transport = _attribute(http, "_transport")
    pool = _attribute(transport, "_pool")
    sdk_closed = _attribute(client, "is_closed")
    # The SDK exposes this as a method; the HTTP client exposes a property.
    if callable(sdk_closed):
        try:
            sdk_closed = sdk_closed()
        except Exception:
            sdk_closed = None
    http_closed = _attribute(http, "is_closed")
    versions = {}
    for package in ("openai", "httpx2"):
        version = _attribute(sys.modules.get(package), "__version__")
        if not isinstance(version, str):
            try:
                version = metadata.version(package)
            except Exception:
                version = None
        versions[package] = version if isinstance(version, str) and re.fullmatch(r"[0-9A-Za-z.+_-]{1,64}", version) else None
    return {"sdk": _class_metadata(client), "http": _class_metadata(http),
            "transport": _class_metadata(transport), "pool": _class_metadata(pool),
            "sdk_closed": sdk_closed if type(sdk_closed) is bool else None,
            "http_closed": http_closed if type(http_closed) is bool else None,
            "client_id": id(client) if client is not None else None,
            "versions": versions}


def _exception_chain(error):
    result, seen = [], set()
    while isinstance(error, BaseException) and id(error) not in seen and len(result) < 8:
        seen.add(id(error))
        classes = _class_metadata(error)
        label = classes["class"].lower()
        codes = {name: _attribute(error, name) for name in ("errno", "winerror", "verify_code")}
        codes = {name: value if type(value) is int else None for name, value in codes.items()}
        flags = {"dns": "gaierror" in label or "nameresolution" in label,
                 "tls": "ssl" in label or "tls" in label or "certificate" in label,
                 "connect": "connect" in label, "read": "read" in label,
                 "write": "write" in label, "pool": "pool" in label,
                 "timeout": "timeout" in label, "resource_fd": codes["errno"] in (23, 24)}
        result.append({"type": classes, **codes, "flags": flags})
        cause = _attribute(error, "__cause__")
        error = (cause if isinstance(cause, BaseException) else
                 None if _attribute(error, "__suppress_context__") else _attribute(error, "__context__"))
    return result


def _response_metadata(response=None, error=None):
    usage = _attribute(response, "usage")
    counts = {name: _attribute(usage, name) for name in ("prompt_tokens", "completion_tokens", "total_tokens")}
    counts["cached_prompt_tokens"] = _attribute(_attribute(usage, "prompt_tokens_details"), "cached_tokens")
    counts = {name: value if type(value) is int and value >= 0 else None for name, value in counts.items()}
    http_response = _attribute(error, "response")
    status = _attribute(error, "status_code")
    if type(status) is not int:
        status = _attribute(http_response, "status_code")
    headers = _attribute(http_response, "headers")
    identifiers = {}
    for name in _REQUEST_ID_HEADERS:
        try:
            value = headers.get(name) if headers is not None else None
        except Exception:
            value = None
        if name == "x-request-id" and value is None:
            value = _attribute(response, "_request_id") or _attribute(error, "request_id")
        if isinstance(value, str) and re.fullmatch(r"[A-Za-z0-9_.:-]{1,160}", value):
            identifiers[name] = value
    return {"usage": counts, "http_status": status if type(status) is int and 100 <= status <= 599 else None,
            "request_ids": identifiers}


def _diagnostic_append(path, record):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as stream:
        stream.write(json.dumps(record, sort_keys=True, allow_nan=False) + "\n")


def _diagnostic_start(client):
    directory = os.getenv(_DIAGNOSTIC_ENV)
    if not directory:
        return None
    try:
        global _diagnostic_pid, _diagnostic_session, _diagnostic_counter, _diagnostic_lock
        pid = os.getpid()
        if _diagnostic_pid != pid:
            _diagnostic_pid, _diagnostic_session, _diagnostic_counter = pid, uuid.uuid4().hex, 0
            _diagnostic_lock = threading.Lock()
        if not _diagnostic_lock.acquire(timeout=0.05):
            return None
        try:
            _diagnostic_counter += 1
            base = {"version": 1, "pid": pid, "ppid": os.getppid(),
                    "counter": _diagnostic_counter, "process_session": _diagnostic_session,
                    "started_utc": datetime.now(timezone.utc).isoformat()}
            state = {"base": base, "started_monotonic": time.monotonic(),
                     "path": Path(directory) / f"azure-diagnostics-{pid}-{_diagnostic_session}.jsonl"}
            _diagnostic_append(state["path"], {**base, "event": "start",
                                "client": _client_metadata(client), "fd_count": _fd_count()})
            return state
        finally:
            _diagnostic_lock.release()
    except Exception:
        return None


def _diagnostic_finish(state, client, response=None, error=None):
    if state is None:
        return
    try:
        record = {**state["base"], "event": "end", "finished_utc": datetime.now(timezone.utc).isoformat(),
                  "duration_seconds": max(0.0, time.monotonic() - state["started_monotonic"]),
                  "outcome": "error" if error is not None else "success",
                  "client": _client_metadata(client), "fd_count": _fd_count(),
                  "exception_chain": _exception_chain(error), **_response_metadata(response, error)}
        if not _diagnostic_lock.acquire(timeout=0.05):
            return
        try:
            _diagnostic_append(state["path"], record)
        finally:
            _diagnostic_lock.release()
    except Exception:
        pass


def make_client(settings, http_client=None):
    from openai import AzureOpenAI
    if not settings.key_present:
        raise ValueError("Fill AZURE_OPENAI.API_KEY in your local config.yml")
    return AzureOpenAI(azure_endpoint=settings.endpoint,
                       api_version=settings.api_version, api_key=settings.api_key,
                       timeout=60.0, max_retries=0, http_client=http_client)


def azure_completion(*args, **kwargs):
    """Preserve the repo's LiteLLM response format using the Azure SDK."""
    import litellm
    global _client
    if args:
        raise TypeError("The local Azure adapter requires keyword arguments")
    if not _settings.matches(kwargs.get("model")):
        raise ValueError("The local Azure launcher supports only its configured deployment")
    if kwargs.get("base_url"):
        raise ValueError("Azure ENDPOINT is configured in config.yml; omit --base_url")
    diagnostic = _diagnostic_start(_client)
    response = None
    try:
        if _client is None:
            _client = make_client(_settings)
        request = {
            "model": _settings.deployment,
            "messages": kwargs["messages"],
            "max_completion_tokens": min(_settings.max_completion_tokens,
                                         kwargs.get("max_completion_tokens") or kwargs.get("max_tokens") or _settings.max_completion_tokens),
            "reasoning_effort": _settings.reasoning_effort,
        }
        # Omit temperature, matching the supplied Azure sample. The SDK bypasses
        # the old LiteLLM model registry, which predates GPT-6.
        if kwargs.get("tools"):
            request["tools"] = kwargs["tools"]
            if kwargs.get("parallel_tool_calls") is not None:
                request["parallel_tool_calls"] = kwargs["parallel_tool_calls"]
        for name in ("tool_choice", "response_format", "stop", "seed"):
            if kwargs.get(name) is not None:
                request[name] = kwargs[name]
        response = _client.chat.completions.create(**request)
        output = litellm.ModelResponse(**response.model_dump(exclude_none=True))
    except Exception as error:
        _diagnostic_finish(diagnostic, _client, response=response, error=error)
        raise
    _diagnostic_finish(diagnostic, _client, response=response)
    return output


def install(settings):
    """Install process-local hooks before importing the project entry point."""
    import litellm
    import utils
    import utils.core_utils as core
    global _settings, _client, _originals
    _settings, _client = settings, None
    if _originals is None:
        _originals = {name: getattr(core, name) for name in
                      ("get_model_provider", "validate_model_api_key", "is_reasoning_llm")}

    def provider(model):
        return "azure" if _settings.matches(model) else _originals["get_model_provider"](model)

    def validate_key(model):
        return _settings.key_present if _settings.matches(model) else _originals["validate_model_api_key"](model)

    def setup_keys():
        # The Azure key is passed only to the Azure client, never installed as
        # OPENAI_API_KEY or printed by the launcher.
        return _settings.key_present

    def reasoning(model):
        return _settings.matches(model) or _originals["is_reasoning_llm"](model)

    hooks = {"get_model_provider": provider, "validate_model_api_key": validate_key,
             "setup_api_keys": setup_keys, "is_reasoning_llm": reasoning}
    for name, value in hooks.items():
        setattr(core, name, value)
        setattr(utils, name, value)
    litellm.completion = azure_completion

    # Azure pricing is not in the pinned LiteLLM registry. Preserve token
    # counts and label monetary cost unknown rather than reporting zero.
    from agent.base_agent import BaseAgent
    original_update = _originals.setdefault("update_usage", BaseAgent._update_usage)

    def update_usage(self, usage_info):
        if not usage_info:
            return
        self.total_usage["cost"] = 0.0
        original_update(self, usage_info)
        self.total_usage.update({"cost": None, "cost_status": "not_estimated",
                                 "provider": "azure", "model": _settings.model,
                                 "deployment": _settings.deployment,
                                 "api_version": _settings.api_version,
                                 "reasoning_effort": _settings.reasoning_effort})

    BaseAgent._update_usage = update_usage
