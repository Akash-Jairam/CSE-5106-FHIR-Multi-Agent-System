# Run C report — V8 convention-verified team vs single agent

**Result: the frozen gate failed.** The V8 team scored 241/300 (80.3 %) against
the fresh single-agent control's 246/300 (82.0 %): −1.7 pts, 95 % CI
[−4.8, +1.4]. Confirmation on the protected questions is not run.

## Setup

| Item | Value |
|---|---|
| Date | 2026-10-16, 18:12–19:16 CDT (≈64 min) |
| Design record | `benchmarks/design-v8-20261016` (frozen before the first attempt) |
| Code | `b50c397` (= `dd0f7d8` plus the freeze record) |
| Questions | `held_out` split, 300 questions, 58 patients |
| Model | gpt-6-luna, `reasoning_effort: none`, for every arm |
| Budget per question | 200k tokens / 30 tool calls (V8 repair capped at 45k / 6 inside that) |
| Workers | 4, `save_interval 1`, gzip audit storage, under `caffeinate -is` on AC power |
| Attempts | 900/900 first attempts, no resume, 0 terminal errors, 0 timeout retries |
| Output | `output/experiments/gpt-6-luna/v8_300q` (local, not committed) |

## Accuracy

95 % CIs are bootstrapped with clustering by patient.

| Arm | Correct | Accuracy | Lookup / counting (n=92) | Numerical aggregation (n=49) | Temporal selection (n=159) |
|---|---|---|---|---|---|
| Direct LLM | 208 | 69.3 % [64.0, 74.7] | 78.3 % | 65.3 % | 65.4 % |
| Single agent | 246 | 82.0 % [76.7, 86.6] | 88.0 % | 81.6 % | 78.6 % |
| V8 team | 241 | 80.3 % [75.1, 85.0] | 85.9 % | 83.7 % | 76.1 % |

Paired differences:

| Comparison | Δ (95 % CI) |
|---|---|
| Team − single | −1.7 pts [−4.8, +1.4]; question wins/losses 11/16 |
| Team − direct | +11.0 pts [+5.2, +16.6] |
| Single − direct | +12.7 pts [+6.6, +18.2] |

The team beat the single agent only on numerical aggregation (+2.1 pts, n=49),
and lost on the other two families.

## Gate (frozen in `design.txt`)

| Condition | Observed | Verdict |
|---|---|---|
| Team > single | −1.7 pts | fail |
| CI lower bound of (team − single) > −2 pts | −4.8 | fail |
| Team transitions wrong→right ≥ right→wrong | 5 vs 6 | fail |

## Cost and latency

| Arm | Total tokens | Mean tokens / question | Model calls | Tool calls | Budget stops | Median latency | p95 latency |
|---|---|---|---|---|---|---|---|
| Direct LLM | 1.94M | 6.5k | 300 | 0 | 0 | 2.4 s | 13.5 s |
| Single agent | 22.20M | 74.0k | 1,974 | 1,982 | 15 | 21.3 s | 43.2 s |
| V8 team | 18.21M | 60.7k | 1,920 | 1,696 | 0 | 19.2 s | 39.8 s |

Unlike V2–V7, which spent about 1.5–1.6× the single's tokens, the V8 team was
cheaper than the single agent (0.82×) and never hit the ceiling.

## Inside the V8 team

**Release policies** (300 questions):

| Policy | Count |
|---|---|
| `source_valid_primary_preserved`: no check fired, or the repair was not released | 276 |
| `primary_failed_execution_or_source_contract`: null answer | 18 |
| `convention_repair_released` | 3 |
| `null_release_repair_released` | 3 |

**Checks that fired** (19 questions): source check 13, tie completeness 5,
specimen field 2. The organism-children, distinct-count-scope and
timestamp-field checks did not fire.

**V8 repairs** (19 run):

| Outcome | Count |
|---|---|
| Released, wrong → right | 3 |
| Released, wrong → wrong | 3 |
| Released, right → wrong | 0 |
| Rejected (still failing or not source-valid) | 10 |
| Failed (no executed final) | 3 |

The repair phases used 474k tokens in total: mean 25k, max 43k, at most 3 tool
calls each. None reached the 45k / 6 cap.

**Where the losses came from.** Across all draft→release changes the team arm
had 5 wrong→right and 6 right→wrong out of 298 scored drafts. Every
right→wrong change came from the solver-revision path inherited from V3d, not
from V8's repairs. The V8 checks themselves were net +3 and did no harm, but
they fired too rarely to offset the inherited losses.

Other team diagnostics: 24/245 answered questions had no cited evidence
(single agent: 24/251). False abstentions were 21/258 for the team and 15/258
for the single agent. The team's 18 null releases (source-check failures that
were not repaired) are the likely source of that gap; this was not broken down further.

## Interpretation

- Deterministic convention checks are safe (no right→wrong) but cover too
  little. The 49-question root-cause audit found the dominant errors were
  convention errors. On the full 300, only 19 drafts tripped a check, and half
  of the released repairs still did not reach the reference answer.
- The shared V3d machinery still costs the team about as much as the checks
  recover, the same pattern as V3d (−2.0) and V7 (−1.7).
- V8 is the closest any team design has come at lower cost than the single,
  but it is still not better. The hypothesis "a verified team beats a
  tool-equipped single agent" remains unsupported on gpt-6-luna.

## Caveats

- The 300 `held_out` questions have been reused across eight design
  iterations, and the V8 checks were calibrated on 49 of them (exposure.md
  §3a/§3b). This number is exploratory, which is why the gate guarded a
  separate confirmation.
- The FHIR store's resource counts moved slightly between the calibration and
  this run (Observations 539,666 → 543,073); these are likely estimate counts
  rather than data changes.
- Single run, single model, one seed.

## Not run

| Experiment | Status |
|---|---|
| Confirmation (launch.md §7) | not run: gate failed |
| C′: heterogeneous verifier | not run: needs a second provider key |
| B1: recovery (200 attempts) | not run |
| B2: weaker base model (900 attempts) | not run: model not chosen |

## Artifacts

- `outcome.txt`: the gate numbers
- `results.json`: paired comparison from `scripts/compare_runs.py`
- `outcome_manifest.json`: checksums from `record_design.py finish`
- `design.txt`, `manifest.json`, `source.zip`: the frozen design
- `docs/diagnosis_v8/report.md`: the cross-design report, with V8 filled in
