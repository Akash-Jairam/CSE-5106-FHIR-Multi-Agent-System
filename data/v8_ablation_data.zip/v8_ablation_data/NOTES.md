# Notes on this bundle (differences from the request)

- **Handoff commit.** `6e77281` does not exist on this machine: the V8 patch was
  applied with `git am`, which rewrote hashes. The equivalent handoff tip here is
  `9eb109e` ("Normalize root_causes.csv line endings"). `changes_since_handoff.txt`
  is `git diff --stat 9eb109e dd0f7d8`; `changes_since_handoff.patch` is the full
  diff of code and tests over the same range (the 3a/3b calibration edits, the
  completion cap, FHIR read retries, and the timeout retry).
- **pc_changes.patch is empty.** Nothing under agent/ tools/ utils/ scripts/
  run_agent.py changed after `dd0f7d8`; the commits after it (`b50c397` freeze,
  `85bd259` results) touch only benchmarks/ and docs/.
- **Section B command.** The request's `analyze`/`revisions` command omits
  `--team_strategy multi_agent_v8 --audit_storage gzip`. Without them every arm is
  rejected as "stale" (fingerprint mismatch). The included `analysis/` and
  `revisions/` were generated with those two flags added and are otherwise
  identical to the requested command.
- **Not included.** `audit/` (as requested); `source.zip` (as requested);
  `.local-provider.json` (does not exist in this output dir); smoke `audit/` dirs.
- **Smoke runs.** `output/smoke/v8_pilot5` was the pre-fix run (completion-cap
  BadRequest), `_r2` an intermediate run, `_r3` the final 5/5 smoke under
  caffeinate. The 3b exploratory runs on the 49 audited questions lived under
  `output/exploratory/` and are not part of the request.
- **Reference answers.** The arm JSONs contain the per-row `true_answer` field as
  written by the runner. `convention_checks_live.json` holds only booleans,
  counts and resource ids.
- **Extra.** `benchmarks/design-v8-20261016/run_c_report.md` is a narrative
  write-up of run C (not committed in git yet).
